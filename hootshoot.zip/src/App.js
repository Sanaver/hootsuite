import './App.css';
import {  Route, Switch  } from "react-router-dom";
import Home from '../src/Pages/Home'
import Publish from '../src/Pages/Publish'
import Engage from '../src/Pages/Engage'
import Advertise from '../src/Pages/Advertise'
import Monitor from '../src/Pages/Monitor'
import Analyze from '../src/Pages/Analyze'
import Facebook from '../src/Pages/Facebook'
import Instagaram from '../src/Pages/Instagaram'
import Youtube from '../src/Pages/Youtube'
import Linkedin from '../src/Pages/Linkedin'
import Twitter from '../src/Pages/Twitter'
import Pinterest from '../src/Pages/Pinterest'

function App() {
  return (
    <div>
      <Switch>

      <Route exact path="/" component={Home} />
      <Route  path="/publish" component={Publish} />
      <Route  path="/engage" component={Engage} />
      <Route  path="/advertise" component={Advertise} />
      <Route  path="/monitor" component={Monitor} />
      <Route  path="/analyze" component={Analyze} />
      <Route  path="/facebook" component={Facebook} />
      <Route  path="/instagaram" component={Instagaram} />
      <Route  path="/youtube" component={Youtube} />
      <Route  path="/linkedin" component={Linkedin} />
      <Route  path="/pinterest" component={Pinterest} />

      </Switch>
    </div>
  );
}

export default App;
