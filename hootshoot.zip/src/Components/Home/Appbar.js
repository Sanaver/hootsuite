import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Button from "@material-ui/core/Button";
import IconButton from "@material-ui/core/IconButton";
import { Container, Box, Drawer } from "@material-ui/core";
import Logo from "../Assets/img/logo.png";
import Drawerr from '../Home/Drawer'
import {Hidden} from '@material-ui/core'

const useStyles = makeStyles((theme) => ({
  appbar: {
    height: "90px",
    backgroundColor: "#fff",
    boxShadow: "none",
    "& .MuiToolbar-regular": {
      minHeight: "90px",
    },
  },
  hvrstng: {
    fontSize:"16px",
              
              fontFamily:"SourceSansPro-SemiBold",
              lineHeight:"22px",
              color:"#241f21",
    cursor: "pointer",
    textTransform: "capitalize",
    paddingLeft:"20px",
    "&:hover": {
      color: "#2f6b9a",
    },
  },
  toolbarButtons: {
    marginLeft: "auto",
    "& .MuiButton-textPrimary": {
      textTransform: "capitalize",
      color: "#241f21",
      fontSize: "16px",
      fontFamily: "SourceSansPro-Regular",
      
      "&:hover": {
        border: "none",
      },
    },
    "& .MuiButton-containedSecondary": {
      padding: "7px 22px",
      backgroundColor: "#28863e !important",
      borderRadius: "0px !important",
      fontSize: "16px",
      fontFamily: "SourceSansPro-Bold",
      textTransform: "capitalize",
      boxShadow: "none",
    },
  },
}));

export default function ButtonAppBar() {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      <AppBar position="static" className={classes.appbar}>
        <Container className="inner-container">
          <Toolbar>
            <IconButton edge="start" color="inherit">
              <img src={Logo} width="125px" />
            </IconButton>
            <Hidden smDown>
            <Button
              pl={2}
              className={classes.hvrstng} >
              Platform
            </Button>
            <Button
              
              className={classes.hvrstng}
              pl={3}
              
              color="#241f21"
            >
              {" "}
              Plans
            </Button>
            <Button
             
              className={classes.hvrstng}
              pl={3}
             
            >
              {" "}
              Enterprise
            </Button>
            <Button
             
              className={classes.hvrstng}
              pl={3}
            
            >
              {" "}
              Resources
            </Button>
            <Button
             
              className={classes.hvrstng}
              pl={3}
           
            >
              {" "}
              Education
            </Button>
            <Box className={classes.toolbarButtons}>
              <Button color="primary">Log in</Button>
              <Button variant="contained" color="secondary">
                Sign Up
              </Button>
            </Box>
            </Hidden>
            <Hidden mdUp >
              <div  className={classes.toolbarButtons}>
            <Drawerr/>
            </div>
            </Hidden>
          </Toolbar>
        </Container>
      </AppBar>
    </div>
  );
}
